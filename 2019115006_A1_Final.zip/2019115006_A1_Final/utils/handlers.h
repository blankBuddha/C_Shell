#ifndef _HANDLERS_H
#define _HANDLERS_H

void remid(int ind)
{
	int job_num = jobs_arr[ind].num;
	for (int i = ind; i < bgsiz - 1; ++i)
	{
		jobs_arr[i].id = jobs_arr[i + 1].id;
		strcpy(jobs_arr[i].command, jobs_arr[i + 1].command);
		jobs_arr[i].num = jobs_arr[i + 1].num;
	}
	--bgsiz;
	for (int i = 0; i < bgsiz; ++i)
	{
		if (jobs_arr[i].num > job_num)
		{
			--jobs_arr[i].num;
		}
	}
}
void exit_bgp(int sig)
{
	int status;
	for (int i = 0; i < bgsiz; ++i)
	{
		if (waitpid(jobs_arr[i].id, &status, WNOHANG) > 0)
		{
			int n_pid = jobs_arr[i].id;
			if (!WIFEXITED(status))
			{
				fprintf(stderr, "%s with pid %d exited abnormally\n", jobs_arr[i].command, n_pid);
			}
			else
			{
				fprintf(stderr, "%s with pid %d exited normally\n", jobs_arr[i].command, n_pid);
			}
			remid(i);
		}
		status = 0;
	}
}
void handle_ctrlc()
{
	if (fgpid < 1)
	{
		return;
	}
	kill(fgpid, SIGINT);
	fgpid = 0;
}
void handle_ctrlz()
{
	if (fgpid < 1)
	{
		return;
	}
	kill(fgpid, SIGTSTP);
	fgpid = 0;
}
#endif
