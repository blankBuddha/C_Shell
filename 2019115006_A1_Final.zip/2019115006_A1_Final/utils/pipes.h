#ifndef _PIPES_H
#define _PIPES_H

void handle_pipes(char *cmd)
{
	int ind = 0, ext = 0;
	char *prt = strtok(cmd, "|");
	char *comlist[20];
	int savestdin = dup(0);

	while (prt)
	{
		comlist[ind] = (char *)malloc(bufsiz);
		strcpy(comlist[ind], prt);
		prt = strtok(NULL, "|");
		++ind;
	}

	for (int i = 0; i < ind; ++i)
	{
		if (i + 1 == ind)
		{
			execute(comlist[i]);
		}
		else
		{
			int fd[2];
			pipe(fd);
			int id = fork();
			if (!id)
			{
				close(fd[0]);
				dup2(fd[1], 1);
				execute(comlist[i]);
				exit(0);
			}
			else if (id > 0)
			{
				wait(NULL);
				close(fd[1]);
				dup2(fd[0], 0);
			}
			close(fd[0]);
			close(fd[1]);
		}
	}
	dup2(savestdin, 0);
	return;
}
#endif