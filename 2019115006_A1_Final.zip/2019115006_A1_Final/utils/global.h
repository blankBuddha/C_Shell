#ifndef _GLOABAL_H
#define _GLOABAL_H
size_t bufsiz = 256;

typedef struct job
{
	int id;
	int num;
	char *command;
} job;

int flag = 0, hombufsiz, stoploop = 0;
char *username, *sysname, *homedir, *lwd;
void execute(char *);
int bgsiz = 0, fgpid = 0;

job jobs_arr[30];

char *makecommand(char **list)
{
	char *cmd = (char *)malloc(sizeof(char) * bufsiz);
	strcpy(cmd, "");
	for (int i = 0; list[i] != NULL; ++i)
	{
		if (!strcmp(list[i], "%"))
		{
			continue;
		}
		strcat(cmd, list[i]);
		strcat(cmd, " ");
	}
	return cmd;
}

void assign_global()
{
	username = (char *)malloc(bufsiz);
	lwd = (char *)malloc(bufsiz);
	homedir = (char *)malloc(bufsiz);
	sysname = (char *)malloc(bufsiz);

	strcpy(lwd, "");
	getcwd(homedir, bufsiz);
	hombufsiz = strlen(homedir);
	
	username = getpwuid(getuid())->pw_name;
	gethostname(sysname, bufsiz);
	for (int i = 0; i < 30; ++i)
	{
		jobs_arr[i].command = (char *)malloc(bufsiz);
	}
}

void separateInputs(char *commands);
#endif