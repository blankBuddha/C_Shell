#ifndef _REDIRECT_H
#define _REDIRECT_H
void redirection(char **list, int indir, int outdir, int outappdir, int inbg)
{
	char *temp;
	temp = (char *)malloc(bufsiz);
	strcpy(temp, "");

	if (inbg)
	{
		strcpy(temp, " &");
	}
	if (indir != -1 && (outappdir != -1 || outdir != -1))
	{
		int fd;
		int savesstdin = dup(0);
		int savesstdout = dup(1);
		char filname[bufsiz];

		int fp = open(list[indir + 1], O_RDONLY);
		if (fp == -1)
		{
			perror("");
			return;
		}

		dup2(fp, STDIN_FILENO);
		int o_out_one = outdir + 1;
		close(fp);
		int o_out_two = outappdir + 1;
		if (outdir == -1)
			sprintf(filname, "%s", list[o_out_two]);
		else
			sprintf(filname, "%s", list[o_out_one]);

		if (outdir == -1)
		{
			fd = open(filname, O_CREAT | O_APPEND | O_WRONLY, 0644);
		}
		else
		{
			fd = open(filname, O_CREAT | O_TRUNC | O_WRONLY, 0644);
		}

		if (fd == -1)
		{
			perror("");
			return;
		}

		if (outdir != -1)
		{
			list[outdir] = "%";
			list[outdir + 1] = "%";
		}
		else
		{
			list[outappdir] = "%";
			list[outappdir + 1] = "%";
		}

		list[indir] = "%";
		list[indir + 1] = "%";
		dup2(fd, STDOUT_FILENO);
		close(fd);
		execute(strcat(makecommand(list), temp));
		dup2(savesstdout, 1);
		dup2(savesstdin, 0);
	}
	else if (outappdir != -1 || outdir != -1)
	{
		int fd;
		char filname[bufsiz];
		int savesstdout = dup(1);
		if (outdir == -1)
		{
			int a_index = outappdir + 1;
			sprintf(filname, "%s", list[a_index]);
		}
		else
		{
			int a_index = outdir + 1;
			sprintf(filname, "%s", list[a_index]);
		}
		if (outdir == -1)
			fd = open(filname, O_CREAT | O_APPEND | O_WRONLY, 0644);
		else
			fd = open(filname, O_CREAT | O_TRUNC | O_WRONLY, 0644);
		if (fd == -1)
		{
			perror("");
			return;
		}

		if (outdir != -1)
		{
			list[outdir] = "%";
			list[outdir + 1] = "%";
		}
		else
		{
			list[outappdir] = "%";
			list[outappdir + 1] = "%";
		}
		dup2(fd, STDOUT_FILENO);
		close(fd);
		execute(strcat(makecommand(list), temp));
		dup2(savesstdout, 1);
	}
	else if (indir != -1)
	{
		int savesstdin = dup(0);
		int fp = open(list[indir + 1], O_RDONLY);
		if (fp == -1)
		{
			perror("");
			return;
		}
		list[indir] = "%";
		list[indir + 1] = "%";
		dup2(fp, STDIN_FILENO);
		close(fp);
		execute(strcat(makecommand(list), temp));
		dup2(savesstdin, 0);
	}
}
#endif