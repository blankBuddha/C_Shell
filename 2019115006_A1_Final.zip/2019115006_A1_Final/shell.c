#include "header.h"
int main()
{
	signal(SIGINT, handle_ctrlc);
	int flags[4];
	for (int i = 0; i < 4; ++i)
	{
		flags[i] = 0;
	}
	++flags[0];
	signal(SIGTSTP, handle_ctrlz);
	++flags[1];
	signal(SIGCHLD, exit_bgp);
	++flags[2];
	assign_global();
	flags[3]++;
	while (1)
	{
		print_shell_prompt();
		takeinput();
	}
	return 0;
}
