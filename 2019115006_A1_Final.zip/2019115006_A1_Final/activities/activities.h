#ifndef _JOBS_H
#define _JOBS_H

void process_activities(char **list, int siz)
{
	int only_running = 0, only_stopped = 0;

	if (siz > 2)
	{
		fprintf(stderr, "Invalid command");
		return;
	}
	if (siz == 2)
	{
		if (strcmp(list[1], "-s") == 0)
		{
			only_stopped = 1;
		}
		else if (strcmp(list[1], "-r") == 0)
		{
			only_running = 1;
		}
		else
		{
			fprintf(stderr, "Invalid flags");
			return;
		}
	}
	for (int i = 0; i < bgsiz; ++i)
	{
		int pid;
		char status;
		char pname[bufsiz];
		char path[bufsiz];
		
		sprintf(path, "/proc/%d/stat", jobs_arr[i].id);
		FILE *fd = fopen(path, "r");
		if (!fd)
		{
			perror("jobs");
			printf("%s [%d]\n", jobs_arr[i].command, jobs_arr[i].id);
			continue;
		}

		fscanf(fd, "%d %s %c", &pid, pname, &status);
		char S_CHAR = 'S', R_CHAR = 'R', T_CHAR = 'T';
		if (only_running && status != S_CHAR && status != R_CHAR)
		{
			continue;
		}
		if (only_stopped && status != T_CHAR)
		{
			continue;
		}

		printf("[%d] ", jobs_arr[i].num);
		if (status == T_CHAR)
		{
			printf("Stopped ");
		}
		else if (status == 'S' || status == 'R')
		{
			printf("Running ");
		}
		else
		{
			printf("Unknown");
		}
		printf("%s [%d]\n", jobs_arr[i].command, jobs_arr[i].id);
		fclose(fd);
	}
}

#endif
