#ifndef _sig_H
#define _sig_H

void process_ping(char **list, int ind)
{
	int pid;
	if (ind != 3)
	{
		fprintf(stderr, "Invalid number of arguments\n");
		return;
	}
	int index = atoi(list[1]), sig = atoi(list[2]);
	if (index - bgsiz > 0 || index == 0)
	{
		fprintf(stderr, "No such process exists\n");
		return;
	}
	for (int i = 0; i < bgsiz; ++i)
	{
		if (index == jobs_arr[i].num)
		{
			pid = jobs_arr[i].id;
			break;
		}
	}
	if (kill(pid, sig) == -1)
	{
		perror("kill");
		return;
	}
}
#endif
