#ifndef _EXECC_H
#define _EXECC_H
void execute(char *command)
{
	int ind = 0, inbg = 0;
	char *list[30];
	char *part = strtok(command, " \t\r\n\a");
	int indir = -1, outdir = -1, outappdir = -1;
	int flag_ = 0;
	while (part)
	{
		list[ind] = (char *)malloc(bufsiz);
		strcpy(list[ind], part);
		if (strcmp(list[ind], "execute") == 0 && strcmp(list[ind-1], "pastevents"))
		{
			flag_ = 1;
		}
		if (strcmp(part, "<") == 0)
		{
			indir = ind;
		}
		else if (strcmp(part, ">") == 0)
		{
			outdir = ind;
		}
		else if (strcmp(part, ">>") == 0)
		{
			outappdir = ind;
		}
		++ind;
		part = strtok(NULL, " \t\r\n\a");
	}
	if (flag_ == 0) 
	{
		read_history(command);
	}
	if (!ind)
	{
		return;
	}
	if (strcmp(list[ind - 1], "&") == 0)
	{
		list[ind - 1] = NULL;
		inbg = 1;
		--ind;
	}
	else
	{
		list[ind] = (char *)malloc(2);
		list[ind] = NULL;
	}
	if (strcmp("quit", list[0]) == 0)
	{
		exit(0);
	}
	else if (indir >= 0 || outdir >= 0 || outappdir >= 0)
	{
		redirection(list, indir, outdir, outappdir, inbg);
	}
	else if (strcmp(list[0], "warp") == 0)
	{
		if (ind == 1)
		{
			process_cd(homedir);
		}
		else if (ind == 2)
		{
			process_cd(list[1]);
		}
		else
		{
			printf("Too many arguments\n");
		}
	}
	else if (strcmp(list[0], "pwd") == 0)
	{
		process_pwd();
	}
	else if (strcmp(list[0], "echo") == 0)
	{
		process_echo(list, ind);
	}
	else if (strcmp(list[0], "peek") == 0)
	{
		process_peek(list, ind);
	}
	else if (strcmp(list[0], "activities") == 0)
	{
		process_activities(list, ind);
	}
	else if (strcmp(list[0], "ping") == 0)
	{
		process_ping(list, ind);
	}
	else if (strcmp(list[0], "fg") == 0)
	{
		process_fg(list, ind);
	}
	else if (strcmp(list[0], "bg") == 0)
	{
		process_bg(list, ind);
	}
	else if (strcmp(list[0], "proclore") == 0)
	{
		if (ind == 1)
		{
			process_proclore(getpid());
		}
		else
		{
			process_proclore(atoi(list[1]));
		}
	}
	else if (strcmp(list[0], "pastevents") == 0)
	{
		if (ind == 1)
		{
			write_history(10);
		}
		else if (ind == 2 && strcmp(list[1], "purge") == 0) 
		{
			delete_history();
		}
		else if (ind == 3 && strcmp(list[1], "execute") == 0)
		{
			char *cmd = execute_history(atoi(list[2]));
			if (cmd)
			{
				separateInputs(cmd);
			}
		}
		else
		{
			write_history(atoi(list[1]));
		}
	}
	else
	{
		handle_bg(list, inbg);
	}
}
#endif
