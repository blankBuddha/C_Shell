#ifndef _INPUT_H
#define _INPUT_H

void separateInputs(char *commands)
{
	char *list[30];
	int ind = 0;
	char *comm = strtok(commands, ";");

	while (comm)
	{
		list[ind] = (char *)malloc(bufsiz);
		strcpy(list[ind], comm);
		comm = strtok(NULL, ";");
		++ind;
	}
	for (int i = 0; i < ind; ++i)
	{
		if (i + 1 == ind)
		{
			flag = 1;
		}
		handle_pipes(list[i]);
	}
}

void takeinput()
{
	flag = 0;
	
	char *commands = (char *)malloc(bufsiz);

	int bytes = getline(&commands, &bufsiz, stdin);

	if (bytes == -1)
	{
		exit(0);
	}
	commands[bytes - 1] = '\0';
	separateInputs(commands);

}

#endif