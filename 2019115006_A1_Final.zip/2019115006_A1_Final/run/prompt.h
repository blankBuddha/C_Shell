#ifndef _PRINT_PROMPT_H
#define _PRINT_PROMPT_H

int ishomepresent(char *path)
{
	int flag_ = 1;
	int currbufsiz = strlen(path);
	if (currbufsiz < hombufsiz)
	{
		return 0;
	}
	for(int i = 0; i < hombufsiz; ++i)
	{
		if (path[i] != homedir[i])
		{
			flag_ = 0;
			break;
		}
	}
	return flag_;
}

void print_shell_prompt()
{
	char *cwd = (char *)malloc(bufsiz);

	printf("\033[1;32m");
	printf("<%s@%s:", username, sysname);

	getcwd(cwd,bufsiz);
	printf("\033[1;34m");

	int flag = ishomepresent(cwd); 
	if (!flag)
	{
		printf("%s", cwd);
	}
	else
	{
		printf("~%s", cwd + hombufsiz);
	}
	printf("\033[0m");
	printf(">");
}
#endif