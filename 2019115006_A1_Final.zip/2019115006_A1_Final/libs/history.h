#ifndef _HISTORY_H
#define _HISTORY_H
void intialize_history()
{
	char path[bufsiz];
	char history[25][bufsiz];
	sprintf(path, "%s/history.txt", homedir);
	if (access(path, F_OK) != -1)
	{
		return;
	}
	FILE *fp = fopen(path, "w");
	strcpy(history[0], "%");
	fwrite(history, sizeof(char), sizeof(history), fp);
	fclose(fp);
}
void read_history(char *command)
{
	intialize_history();
	
	char path[bufsiz];
	char history[60][bufsiz];

	sprintf(path, "%s/history.txt", homedir);
	FILE *fr = fopen(path, "r");
	fread(history, sizeof(char), sizeof(history), fr);
	
	int len = 0;
	while (1)
	{
		if (history[len][0] == '%')
		{
			break;
		}
		++len;
	}
	fclose(fr);
	if (len > 0 && strcmp(history[len - 1], command) == 0)
	{
		return;
	}
	if (len == 50)
	{
		for (int i = 0; i < len; ++i)
		{
			strcpy(history[i], history[i + 1]);
		}
		--len;
	}
	strcpy(history[len], command);
	strcpy(history[len + 1], "%");
	
	FILE *fp = fopen(path, "w+");
	fwrite(history, sizeof(char), sizeof(history), fp);
	fclose(fp);
}
void delete_history() 
{
	char path[bufsiz];
	char *init = (char *)malloc(bufsiz);
	sprintf(path, "%s/history.txt", homedir);

	FILE *fp = fopen(path, "w+");
	strcpy(init, "%");
	fwrite(init, sizeof(char), sizeof(init), fp);
	fclose(fp);

}
char* execute_history(int num)
{
	char path[bufsiz];
	char history[25][bufsiz];
	
	sprintf(path, "%s/history.txt", homedir);
	FILE *fr = fopen(path, "r");
	if (!fr)
	{
		fprintf(stderr, "Failed to read history file\n");
		return NULL;
	}
	fread(history, sizeof(char), sizeof(history), fr);

	int len = 0;
	while (1)
	{
		if (history[len][0] == '%')
			break;
		++len;
	}

	int ind = len - num;
	if (len < num || num == 0)
	{
		fprintf(stderr,"Index does not exist\n");
		return NULL;
	}
	char *cmd = history[ind];
	return cmd;
	
}
void write_history(int num)
{
	if (num > 50)
		num = 50;
	
	char path[bufsiz];
	char history[60][bufsiz];
	
	sprintf(path, "%s/history.txt", homedir);
	FILE *fr = fopen(path, "r");
	if (!fr)
	{
		fprintf(stderr, "Failed to read history file\n");
		return;
	}
	fread(history, sizeof(char), sizeof(history), fr);

	int len = 0;
	while (1)
	{
		if (history[len][0] == '%')
			break;
		++len;
	}
	
	int ind = len - num;
	if (ind < 0)
	{
		ind = 0;
	}
	while (1)
	{
		if (ind == len|| !num)
		{
			break;
		}
		printf("%s\n", history[ind]);
		++ind;
		--num;
	}
	fclose(fr);
}
#endif
