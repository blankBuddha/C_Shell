#ifndef _PINFO_H
#define _PINFO_H

void process_proclore(int pid)
{
	int cnt = 0;
	char linkpath[bufsiz], path[bufsiz], str[bufsiz];
	char exp[bufsiz];

	sprintf(path, "/proc/%d/stat", pid);
	FILE *fd = fopen(path, "r");
	sprintf(linkpath, "/proc/%d/exe", pid);

	if (!fd)
	{
		fprintf(stderr, "No such process exists\n");
		return;
	}
	printf("pid -- %d\n", pid);
	
	while (fscanf(fd, "%s", str))
	{
		++cnt;
		if (cnt == 3)
		{
			printf("PROCESS STATUS -- %s\n", str);
		}
		else if (cnt == 23)
		{
			printf("memory -- %s\n", str);
			break;
		}
	}
	
	int bytes = readlink(linkpath, exp, bufsiz);
	if (bytes < 0)
	{
		perror("Executable Path");
		return;
	}
	exp[bytes] = '\0';
	if (ishomepresent(exp))
	{
		printf("Executable Path -- ~%s\n", exp + hombufsiz);
	}
	else
	{
		printf("Executable Path -- %s\n", exp);
	}
	fclose(fd);
	return;
}
#endif
