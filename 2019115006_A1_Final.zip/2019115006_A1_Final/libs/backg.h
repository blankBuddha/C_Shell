#ifndef _BACKG_H
#define _BACKG_H
void sort_jobs()
{
	for (int i = 0; i < bgsiz - 1; ++i)
	{
		int sorted = 1;
		for (int j = 0; j < bgsiz - i - 1; ++j)
		{
			int swap = 0, len;
			int len2 = strlen(jobs_arr[j + 1].command);
			int len1 = strlen(jobs_arr[j].command);
			if (len1 < len2)
				len = len1;
			else
				len = len2;
			for (int k = 0; k < len; ++k)
			{
				if (jobs_arr[j].command[k] == jobs_arr[j + 1].command[k])
				{
					continue;
				}
				else if (jobs_arr[j].command[k] > jobs_arr[j + 1].command[k])
				{
					swap = 1;
				}
				else
				{
					swap = 2;
				}
				break;
			}
			if (len1 > len2 && !swap)
			{
				swap = 1;
			}
			if (swap == 1)
			{
				sorted = 0;
				char *temp_command = (char *)malloc(bufsiz);
				int temp_id = jobs_arr[j + 1].id, temp_num = jobs_arr[j + 1].num;
				strcpy(temp_command, jobs_arr[j + 1].command);
				strcpy(jobs_arr[j + 1].command, jobs_arr[j].command);
				strcpy(jobs_arr[j].command, temp_command);
				jobs_arr[j + 1].id = jobs_arr[j].id;
				jobs_arr[j + 1].num = jobs_arr[j].num;
				jobs_arr[j].num = temp_num;
				jobs_arr[j].id = temp_id;
			}
		}
		if (sorted)
		{
			break;
		}
	}
}
void handle_bg(char **list, int inbg)
{
	int id = fork();
	int stat, p_num = 0;
	if (id == -1)
	{
		perror("");
		return;
	}
	else
	{
		if (!inbg)
		{
			if (id)
			{
				signal(SIGTTOU, SIG_IGN);
				signal(SIGTTIN, SIG_IGN);
				tcsetpgrp(STDIN_FILENO, id);
				waitpid(id, &stat, WUNTRACED);
				tcsetpgrp(STDIN_FILENO, getpgrp());
				if (WIFSTOPPED(stat))
				{

					jobs_arr[bgsiz].command = makecommand(list);
					jobs_arr[bgsiz].num = bgsiz + 1;
					jobs_arr[bgsiz].id = id;
					++bgsiz;
					sort_jobs();
				}
				signal(SIGTTOU, SIG_DFL);
				signal(SIGTTIN, SIG_DFL);
				fgpid = 0;
			}
			else
			{
				if (setpgid(0, 0) < 0)
				{
					perror("");
				}
				if (execvp(list[0], list) < 0)
				{
					perror("execvp");
				}
				exit(1);
			}
		}
		else
		{
			if (id)
			{
				jobs_arr[bgsiz].command = makecommand(list);
				jobs_arr[bgsiz].num = bgsiz + 1;
				jobs_arr[bgsiz].id = id;
				++bgsiz;
				fprintf(stderr, "[%d] %d\n", bgsiz, id);
				sort_jobs();
			}
			else
			{
				if (setpgid(0, 0) < 0)
				{
					perror("");
				}
				if (execvp(list[0], list) < 0)
				{
					perror("execvp");
				}
				exit(1);
			}
		}
	}
}
#endif
