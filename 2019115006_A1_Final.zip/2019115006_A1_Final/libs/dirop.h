#ifndef _DIROP_H
#define _DIROP_H
void process_cd(char *arg)
{
	char flag = arg[0];
	char *cwd = (char *)malloc(bufsiz);
	getcwd(cwd, bufsiz);
	int check;
	if (flag == '-')
	{
		if (!strcmp(lwd, ""))
		{
			printf("%s\n", cwd);
			return;
		}
		printf("%s\n", lwd);
		check = chdir(lwd) == -1;
	}
	else if (flag == '~')
	{
		check = chdir(homedir);
		if (strlen(arg) > 2)
			chdir(arg + 3);
	}
	else
	{
		check = chdir(arg);
	}
	if (check != -1)
	{
		strcpy(lwd, cwd);
	}
	else
	{
		perror("");
		return;
	}
}

void process_pwd()
{
	char *cwd = (char *)malloc(bufsiz);
	getcwd(cwd, bufsiz);
	if (!cwd)
	{
		perror("pwd");
		return;
	}
	printf("%s\n", cwd);
}

void process_echo(char **list, int tot)
{
	for (int i = 1; i < tot; ++i)
	{
		printf("%s", list[i]);
		if (i + 1 < tot)
			printf(" ");
	}
	puts("");
}
#endif