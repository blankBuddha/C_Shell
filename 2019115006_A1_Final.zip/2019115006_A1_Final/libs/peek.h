#ifndef _LS_H
#define _LS_H

void process_peek(char **list, int siz)
{
	int ind = 0;
	int take_hidden = 0, print_big = 0;
	char dirpath[10][bufsiz];
	
	DIR *currdir;
	for (int i = 1; i < siz; ++i)
	{
		char char_check = list[i][0];
		if (char_check == '&')
			continue;
		else if (char_check == '-')
		{
			for (int j = 1; list[i][j] != '\0'; ++j)
			{
				char char_check = list[i][j];
				if (char_check == 'a')
				{
					take_hidden = 1;
				}
				else if (char_check == 'l')
				{
					print_big = 1;
				}
				else
				{
					fprintf(stderr, "Invalid option\n");
					return;
				}
			}
		}
		else if (char_check == '~')
		{
			int arg_lens = strlen(list[i]);
			if (arg_lens > 1)
			{
				--arg_lens;
				sprintf(dirpath[ind], "%s%s", homedir, list[i] + 1);
			}
			else
			{
				++arg_lens;
				sprintf(dirpath[ind], "%s", homedir);
			}
			++ind;
		}
		else
		{
			int max_lens = strlen(list[i]) + 1;
			strcpy(dirpath[ind], list[i]);
			++ind;
		}
	}

	if (!ind)
	{
		getcwd(dirpath[0], bufsiz);
		++ind;
	}
	for (int k = 0; k < ind; ++k)
	{
		char filpath[bufsiz], mtime[bufsiz];
		struct stat fil;
		struct dirent **filelist;
		
		if (ind > 1)
		{
			if (k)
			{
				puts("");
			}
			printf("%s:\n", dirpath[k]);
		}
		
		int numfiles = scandir(dirpath[k], &filelist, NULL, alphasort);
		if (numfiles < 0)
		{
			perror("");
			puts("");
			continue;
		}
		if (print_big == 1)
		{
			int total = 0, width = 0;
			char num[50];
			for (int i = 0; i < numfiles; ++i)
			{
				char char_check = filelist[i]->d_name[0];
				if (take_hidden == 0 && char_check == '.')
					continue;
				sprintf(filpath, "%s/%s", dirpath[k], filelist[i]->d_name);
				stat(filpath, &fil);

				int wid = sprintf(num, "%ld", fil.st_size);
				int div = fil.st_blocks / 2;
				if (width < wid)
				{
					width = wid;
				}
				total = total + div;
			}
			printf("total %d\n", total);
			for (int i = 0; i < numfiles; ++i)
			{
				char char_check = filelist[i]->d_name[0];
				char permissions[10];
				if (take_hidden == 0 && char_check == '.')
					continue;
				sprintf(filpath, "%s/%s", dirpath[k], filelist[i]->d_name);
				stat(filpath, &fil);
    			
				struct group *g = getgrgid(fil.st_gid);
				struct passwd *user = getpwuid(fil.st_uid);
				strftime(mtime, bufsiz, "%b %d %H:%M", localtime(&fil.st_mtim.tv_sec));

				printf((S_ISDIR(fil.st_mode)) ? "d" : "-");
				printf((S_IRUSR & fil.st_mode) ? "r" : "-");
				printf((S_IWUSR & fil.st_mode) ? "w" : "-");
				printf((S_IXUSR & fil.st_mode) ? "x" : "-");
				printf((S_IRGRP & fil.st_mode) ? "r" : "-");
				printf((S_IWGRP & fil.st_mode) ? "w" : "-");
				printf((S_IXGRP & fil.st_mode) ? "x" : "-");
				printf((S_IROTH & fil.st_mode) ? "r" : "-");
				printf((S_IWOTH & fil.st_mode) ? "w" : "-");
				printf((S_IXOTH & fil.st_mode) ? "x" : "-");
				printf(" %2ld", fil.st_nlink);
				printf(" %s", user->pw_name);
				printf(" %s", g->gr_name);
				printf(" %*ld", width, fil.st_size);
				printf(" %s", mtime);
				printf(" %s", filelist[i]->d_name);
				free(filelist[i]);
				puts("");
			}
		}
		else
		{
			int numfiles = scandir(dirpath[k], &filelist, NULL, alphasort);
			for (int i = 0; i < numfiles; ++i)
			{
				char char_check = filelist[i]->d_name[0];
				if (take_hidden == 0 && char_check == '.')
				{
					continue;
				}
				printf("%s ", filelist[i]->d_name);
				free(filelist[i]);
				puts("");
			}
		}
		free(filelist);
	}
	return;
}

#endif
